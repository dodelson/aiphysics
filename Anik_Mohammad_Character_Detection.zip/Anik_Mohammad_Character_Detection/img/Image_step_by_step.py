import torch
import torchvision

n_epochs = 3
batch_size_train = 1
batch_size_test = 1000
learning_rate = 0.01
momentum = 0.5
log_interval = 10

import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from skimage import io, color
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim  
from PIL import Image
import os
import PIL
import glob




size = 28, 28
im = Image.open("img001-001.png")
im_resized = im.resize(size, Image.ANTIALIAS)
im_resized.save("x.png", "PNG")

image = mpimg.imread('x.png')
imgplot = plt.imshow(image)

lina_gray = color.rgb2gray(image)



x = torch.zeros((1,1,28,28)) 
x[0][0] = torch.tensor(lina_gray)
a = np.zeros((1),dtype = int) 
y = torch.LongTensor(a)


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, 10)

    def forward(self, x):
        #x = torch.zeros((1000,1,28,28))
        #print(x.size())
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x)

network = Net()
optimizer = optim.SGD(network.parameters(), lr=learning_rate,
                      momentum=momentum)
    
train_losses = []
train_counter = []
test_losses = []



for epoch in range(1, n_epochs + 1):
    network.train()
    optimizer.zero_grad()
    output = network(x)
    loss = F.nll_loss(output, y)
    loss.backward()
    optimizer.step()

      
      
      


















#image = mpimg.imread('img019-049.png')
##
##
#hello = image[0:900,0:900,0:3]
#
#size = 28, 28
#im_resized = hello.resize(size, Image.ANTIALIAS)
#
#imgplot = plt.imshow(hello)
#
#lina_gray = color.rgb2gray(hello)
#plt.imshow(lina_gray,cmap='gray', interpolation='none')
#
#img = lina_gray.resize((28, 28))


#imgplot = plt.imshow(img)
#
#lina_gray = color.rgb2gray(img)
##lina_gray_tensor = torch.tensor(lina_gray)
##plt.imshow(lina_gray,cmap='gray', interpolation='none')
#
#new_image = lina_gray[0:900,0:900]

#
#img = new_image.resize((28, 28))


