import torch
import torchvision
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from skimage import io, color
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim  
from PIL import Image
import os
import PIL
import glob
import random

#n_epochs = 3
#batch_size_train = 1
#batch_size_test = 64
learning_rate = 0.1
momentum = 0.9
log_interval = 10




def character_print(x):
    if(x == 0):
        char = "0"
    elif(x == 1):
        char = "1"
    elif(x == 2):
        char = "2"            
    elif(x == 3):
        char = "3"
    elif(x == 4):
        char = "4"            
    elif(x == 5):
        char = "5"
    elif(x == 6):
        char = "6"            
    elif(x == 7):
        char = "7"
    elif(x == 8):
        char = "8"            
    elif(x == 9):
        char = "9"
    elif(x == 10):
        char = "A"            
    elif(x == 11):
        char = "B"
    elif(x == 12):
        char = "C"            
    elif(x == 13):
        char = "D"
    elif(x == 14):
        char = "E"            
    elif(x == 15):
        char = "F"
    elif(x == 16):
        char = "G"             
    elif(x == 17):
        char = "H"
    elif(x == 18):
        char = "I"            
    elif(x == 19):
        char = "J"
    elif(x == 20):
        char = "K"            
    elif(x == 21):
        char = "L"
    elif(x == 22):
        char = "M"            
    elif(x == 23):
        char = "N"
    elif(x == 24):
        char = "O"            
    elif(x == 25):
        char = "P"
    elif(x == 26):
        char = "Q"            
    elif(x == 27):
        char = "R"
    elif(x == 28):
        char = "S"            
    elif(x == 29):
        char = "T"
    elif(x == 30):
        char = "U"            
    elif(x == 31):
        char = "V"
    elif(x == 32):
        char = "W"            
    elif(x == 33):
        char = "X"
    elif(x == 34):
        char = "Y"            
    elif(x == 35):
        char = "Z"
    elif(x == 36):
        char = "a"            
    elif(x == 37):
        char = "b"
    elif(x == 38):
        char = "c"            
    elif(x == 39):
        char = "d"
    elif(x == 40):
        char = "e"            
    elif(x == 41):
        char = "f"
    elif(x == 42):
        char = "g"            
    elif(x == 43):
        char = "h"
    elif(x == 44):
        char = "i"            
    elif(x == 45):
        char = "j"
    elif(x == 46):
        char = "k"            
    elif(x == 47):
        char = "l"
    elif(x == 48):
        char = "m"             
    elif(x == 49):
        char = "n"
    elif(x == 50):
        char = "o"            
    elif(x == 51):
        char = "p"
    elif(x == 52):
        char = "q"            
    elif(x == 53):
        char = "r"
    elif(x == 54):
        char = "s"            
    elif(x == 55):
        char = "t"
    elif(x == 56):
        char = "u"            
    elif(x == 57):
        char = "v"
    elif(x == 58):
        char = "w"            
    elif(x == 59):
        char = "x"
    elif(x == 60):
        char = "y"            
    elif(x == 61):
        char = "z"    
    return char


#size = 28, 28
#index = 1
#for i in range(1,63):
#    for j in range (1,56):
#        if(i < 10):
#           str1 = "00"+str(i)
#        else:
#            str1 = "0"+str(i)
#            
#        if(j < 10):
#           str2 = "00"+str(j)
#        else:
#            str2 = "0"+str(j)            
#            
#        im = Image.open("img"+str1+"-"+str2+".png")
#        im_resized = im.resize(size, Image.ANTIALIAS)
#        im_resized.save(str(index)+".png", "PNG")
#        index = index + 1



Dataset_Feature = torch.zeros((3410,1,28,28)) 
Dataset_y = np.zeros((3410),dtype = int)  
cnt = 0
for i in range(1,3411):
    image = mpimg.imread(str(i)+'.png')
    lina_gray = color.rgb2gray(image)
    Dataset_Feature[i-1][0] = torch.tensor(lina_gray)
    Dataset_y[i-1] = cnt
    if(i % 55 == 0):
      cnt = cnt + 1  
    
Dataset_target = torch.LongTensor(Dataset_y)


my_list=random.sample(range(3410), 3410)


X_train = Dataset_Feature[my_list[0:2700]]
X_test = Dataset_Feature[my_list[2700:]]

Y_train = Dataset_target[my_list[0:2700]]
Y_test = Dataset_target[my_list[2700:]]


#a = a = np.zeros((1),dtype = int) 
#y = torch.LongTensor(a)
#
#
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, 62)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x)

network = Net()
optimizer = optim.SGD(network.parameters(), lr=learning_rate, momentum=momentum)
    
train_losses = []
train_counter = []
test_losses = []



for epoch in range(1, 1000):
    network.train()
    optimizer.zero_grad()
    output = network(X_train)
    loss = F.nll_loss(output, Y_train)
    loss.backward()
    print(loss)
    optimizer.step()


network.eval()
test_loss = 0
correct = 0
output = network(X_test)
test_loss += F.nll_loss(output, Y_test, size_average=False).item()
pred = output.data.max(1, keepdim=True)[1]
correct += pred.eq(Y_test.data.view_as(pred)).sum()

print("correct: " + str(correct))



      
  